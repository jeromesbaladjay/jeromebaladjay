// 1. REFRESH CHECK: Remove any stuck panel from previous versions
const oldPanel = document.getElementById("text-matcher-panel");
if (oldPanel) oldPanel.remove();

let enabled = false;

// 2. MODERN UI CONSTRUCTION
const panel = document.createElement("div");
panel.id = "text-matcher-panel";
panel.style.cssText = `
  position: fixed; top: 20px; right: 20px; width: 350px;
  background: #0f172a; border: 1px solid #334155; border-radius: 12px;
  z-index: 2147483647; box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.4);
  font-family: 'Inter', sans-serif; display: none; flex-direction: column;
  overflow: hidden; color: #f8fafc;
`;

panel.innerHTML = `
  <div style="display: flex; justify-content: space-between; align-items: center; padding: 14px 18px; background: #1e293b; border-bottom: 1px solid #334155;">
    <div style="display: flex; align-items: center; gap: 10px;">
      <div style="width: 10px; height: 10px; background: #3b82f6; border-radius: 2px; box-shadow: 0 0 8px #3b82f6;"></div>
      <h4 style="margin: 0; font-size: 13px; font-weight: 700; color: #94a3b8; text-transform: uppercase;">Content Checker</h4>
    </div>
    <button id="text-matcher-exit-btn" style="background: none; border: none; cursor: pointer; color: #64748b; font-size: 22px;">&times;</button>
  </div>
  <div style="padding: 18px; display: flex; flex-direction: column; gap: 14px;">
    <textarea id="note-input" placeholder="Paste content to verify..." style="width: 100%; height: 120px; padding: 12px; font-size: 13px; color: #e2e8f0; background: #020617; border: 1px solid #334155; border-radius: 8px; resize: none; outline: none; font-family: monospace;"></textarea>
    <button id="match-notes-btn" style="width: 100%; padding: 12px; background: #2563eb; color: #fff; border: none; border-radius: 8px; font-size: 14px; font-weight: 600; cursor: pointer;">RUN SCAN</button>
    <div id="text-matcher-message-box" style="display: none; padding: 14px; border-radius: 8px; font-size: 13px; line-height: 1.5; border: 1px solid transparent; max-height: 200px; overflow-y: auto;"></div>
  </div>
`;

document.body.appendChild(panel);

// 3. CORE LOGIC: Aggressive Normalization & Exclusion
const clearHighlights = () => {
  const highlights = document.querySelectorAll("mark.text-match-highlight");
  highlights.forEach(mark => {
    const parent = mark.parentNode;
    if (parent) {
      parent.replaceChild(document.createTextNode(mark.textContent), mark);
      parent.normalize(); 
    }
  });
};

const walkAndHighlight = (node, phrases) => {
  // IGNORE THE PANEL: If the current node is inside our extension UI, skip it entirely.
  if (node.nodeType === Node.ELEMENT_NODE && node.id === "text-matcher-panel") return;

  if (node.nodeType === Node.TEXT_NODE && node.parentNode) {
    const text = node.nodeValue;
    const escaped = phrases.filter(p => p).map(p => p.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')).join('|');
    if (!escaped) return;

    const regex = new RegExp(escaped, 'gi');
    if (!regex.test(text)) return;

    const frag = document.createDocumentFragment();
    let lastIndex = 0;
    text.replace(regex, (match, offset) => {
      frag.appendChild(document.createTextNode(text.slice(lastIndex, offset)));
      const mark = document.createElement("mark");
      mark.className = "text-match-highlight";
      mark.textContent = match;
      mark.style.cssText = "background: #3b82f6; color: white; border-radius: 3px; padding: 0 2px;";
      frag.appendChild(mark);
      lastIndex = offset + match.length;
    });
    frag.appendChild(document.createTextNode(text.slice(lastIndex)));
    node.parentNode.replaceChild(frag, node);
  } else if (
    node.nodeType === Node.ELEMENT_NODE && 
    !node.closest('#text-matcher-panel') && // DOUBLE CHECK: skip if ancestor is the panel
    node.tagName !== 'MARK' &&
    node.tagName !== 'SCRIPT' &&
    node.tagName !== 'STYLE'
  ) {
    Array.from(node.childNodes).forEach(child => walkAndHighlight(child, phrases));
  }
};

const scanBtn = document.getElementById("match-notes-btn");

scanBtn.addEventListener("click", () => {
  const box = document.getElementById("text-matcher-message-box");
  const input = document.getElementById("note-input").value.trim();
  
  clearHighlights(); 
  
  if (!input) {
    box.style.display = "none";
    scanBtn.innerText = "RUN SCAN";
    return;
  }

  setTimeout(() => {
    const normalizeText = str => str.toLowerCase().replace(/\s+/g, ' ').trim();
    
    // THE FIX: Instead of checking the whole document.body, 
    // we iterate through all elements and skip the extension panel.
    let pageContent = "";
    document.querySelectorAll("body *:not(#text-matcher-panel):not(#text-matcher-panel *)").forEach(el => {
        // Only grab direct text from visible elements that aren't scripts/styles
        if (el.offsetParent !== null && !['SCRIPT', 'STYLE', 'MARK'].includes(el.tagName)) {
            // We use a specific selector to ensure we don't grab the panel's children
            const clone = el.cloneNode(true);
            pageContent += " " + clone.innerText;
        }
    });

    const pageText = normalizeText(pageContent);
    const phrases = input.split(/\n|\r/).map(line => line.trim()).filter(Boolean);
    const missing = phrases.filter(p => !pageText.includes(normalizeText(p)));

    walkAndHighlight(document.body, phrases);

    scanBtn.innerText = "RE-SCAN CONTENT";
    box.style.display = "block";
    
    if (missing.length > 0) {
      box.style.background = "rgba(239, 68, 68, 0.1)";
      box.style.color = "#f87171";
      box.style.borderColor = "rgba(239, 68, 68, 0.2)";
      box.innerHTML = `
        <div style="font-weight: 700; margin-bottom: 5px;"> MISSING ITEMS (${missing.length}):</div>
        <ul style="margin: 0; padding-left: 18px; font-family: monospace; font-size: 12px;">
          ${missing.map(m => `<li>${m}</li>`).join('')}
        </ul>
      `;
    } else {
      box.style.background = "rgba(16, 185, 129, 0.1)";
      box.style.color = "#34d399";
      box.style.borderColor = "rgba(16, 185, 129, 0.2)";
      box.innerHTML = `<strong> SCAN SUCCESS:</strong> All content matches correctly.`;
    }
  }, 30);
});

document.getElementById("note-input").addEventListener("input", () => {
  scanBtn.innerText = "RUN SCAN";
});

document.getElementById("text-matcher-exit-btn").onclick = () => panel.style.display = "none";

if (typeof chrome !== "undefined" && chrome.runtime && chrome.runtime.onMessage) {
  chrome.runtime.onMessage.addListener((msg) => {
    if (msg.action === "toggle-panel") {
      enabled = !enabled;
      panel.style.display = enabled ? "flex" : "none";
      if (!enabled) clearHighlights();
    }
  });
}